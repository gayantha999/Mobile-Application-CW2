package com.example.cw2_mobile;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.ListView;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class Databasehelper extends SQLiteOpenHelper {
    //put database name
    private static final String DATABASE_NAME="movie_database";

    public Databasehelper(@Nullable Context context)
    {
        super(context, DATABASE_NAME, null, 6);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)
    //then creating a table
    {
        String qry="create table movie_table( id integer primary key autoincrement, title text, year text, direc text, nameList text , rating float, review text,status int)";
        sqLiteDatabase.execSQL(qry);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1)
    //if table exist
    {
        String qry="DROP TABLE IF EXISTS movie_table";
        sqLiteDatabase.execSQL(qry);
        onCreate(sqLiteDatabase);
    }
    //adding a record
    public  String addrecord(String title, int year, String direc, String nameList, float rating, String review)
    {

        SQLiteDatabase db=this.getWritableDatabase();

        ContentValues cv=new ContentValues();
        cv.put("title",title);
        cv.put("year",year);
        cv.put("direc",direc);
        cv.put("nameList",nameList);
        cv.put("rating",rating);
        cv.put("review",review);
        //cv.put("status",status);
        float number=db.insert("movie_table",null,cv);

        if(number==-1)
            return "Failed";
        else
            return  "Successfully Inserted";

    }

    //update value we use update method
    public  String update( String id, String movie_title, int MOVIE_year, String director,String Cast_name, int rating,String Review ,int status)
    {
        SQLiteDatabase db=this.getWritableDatabase();

        ContentValues cv=new ContentValues();
        cv.put("movie_title",movie_title);
        cv.put("MOVIE_year",MOVIE_year);
        cv.put("director",director);
        cv.put("Cast_name",Cast_name);
        cv.put("rating",rating);
        cv.put("Review",Review);
        cv.put("status",status);
        float res=db.update("tbl_movie",cv,"id=?",new String[]{id});

        if(res==-1)
            return "Failed";

            return  "Successfully inserted";

    }

    //display the record in database
    public Cursor readalldata()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        String qry="select * from movie_table order by title asc";
        Cursor cursor=db.rawQuery(qry,null);
        return  cursor;
    }
    public Cursor Title(){
        SQLiteDatabase db =this.getWritableDatabase();
        String qry ="select * from movie_table order by title asc";
        Cursor cursor=db.rawQuery(qry,null);
        return  cursor;
    }


}



