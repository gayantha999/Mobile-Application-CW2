package com.example.cw2_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3,b4,b5,b6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.buttonReg);
        b1.setBackgroundColor(Color.LTGRAY);
        b2=findViewById(R.id.buttonDisplay);
        b2.setBackgroundColor(Color.YELLOW);
        b3=findViewById(R.id.buttonFavourite);
        b3.setBackgroundColor(Color.GREEN);
        b4=findViewById(R.id.buttonEdit);
        b4.setBackgroundColor(Color.RED);
        b5=findViewById(R.id.buttonSearch);
        b5.setBackgroundColor(Color.MAGENTA);
        b6=findViewById(R.id.buttonRating);
        b6.setBackgroundColor(Color.BLUE);





        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRegMovie();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDisplayMovie();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFavourite();
            }
        });


        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEditMovie();
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSearch();
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRatings();
            }
        });
    }


    public void openRegMovie(){
        Intent intentReg=new Intent(this,RegisterMovie.class);
        startActivity(intentReg);
    }

    public void openDisplayMovie(){
        Intent intentDisplay=new Intent(this,DisplayMovie.class);
        startActivity(intentDisplay);
    }
    public void openEditMovie(){
        Intent intentEdit=new Intent(this,EditMovie.class);
        startActivity(intentEdit);
    } public void openFavourite(){
        Intent intentFav=new Intent(this,Favourite.class);
        startActivity(intentFav);
    } public void openSearch(){
        Intent intentSearch=new Intent(this,Search.class);
        startActivity(intentSearch);
    } public void openRatings(){
        Intent intentRatings=new Intent(this,Ratings.class);
        startActivity(intentRatings);
    }
}