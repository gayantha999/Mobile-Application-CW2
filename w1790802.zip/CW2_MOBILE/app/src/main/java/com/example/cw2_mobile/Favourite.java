package com.example.cw2_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Favourite extends AppCompatActivity {
    Databasehelper myDB;
//    ArrayList<movies>movieDisplay;
//    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);
//        recyclerView=findViewById(R.id.rv);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ListView listView =(ListView)findViewById(R.id.listSearch);
        myDB=new Databasehelper(this);

        ArrayList<String>listDisplay=new ArrayList<>();
        Cursor cursor=myDB.readalldata();




        if (cursor.getCount()==0 ){
            Toast.makeText(Favourite.this,"The database was empty",Toast.LENGTH_SHORT).show();
        }
        else{
            while (cursor.moveToNext()){
                listDisplay.add(cursor.getString(1));
                ListAdapter listAdapter=new ArrayAdapter(this, android.R.layout.simple_list_item_1,listDisplay);
                listView.setAdapter(listAdapter);

            }
        }


    }
    }





























