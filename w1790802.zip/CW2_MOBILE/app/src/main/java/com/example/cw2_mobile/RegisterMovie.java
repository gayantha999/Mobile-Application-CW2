package com.example.cw2_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.DatabaseMetaData;

public class RegisterMovie extends AppCompatActivity {

    //DatabaseHelper db;

    EditText e1,e2,e3,e4,e5,e6;
    TextView t1;
     Button Save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_movie);
        e1 = findViewById(R.id.editTextTitle);
        e2 = findViewById(R.id.eidTextYear);
        e3 = findViewById(R.id.editTextDirector);
        e4 = findViewById(R.id.editTextList);
        e5 = findViewById(R.id.editTextRatings);
        e6 = findViewById(R.id.editTextReview);
        Save = findViewById(R.id.buttonSaveReg);
        final Databasehelper dataBaseHelper=new Databasehelper(this);

      Save.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              String  name =e1.getText().toString();
              int year=Integer.parseInt(e2.getText().toString());
              String director=e3.getText().toString();
              String list=e4.getText().toString();
              int ratings=Integer.parseInt(e5.getText().toString());
              String review=e6.getText().toString();

              if (name.isEmpty()){
                  e1.setError("insert data");
              }
              else if(director.isEmpty()){
                  e3.setError("insert data");
              }else if(list.isEmpty()){
                  e4.setError("insert data");
              }else if(review.isEmpty()){
                  e6.setError("insert data");
              }else if (year<1895){
                  e2.setError("Enter correct year");
              }
              else if (ratings>10){
                  e5.setError("Enter Valid rating");
              }
              else{
                  String insert=dataBaseHelper.addrecord(name,year,director,list,ratings,review);
                  Toast.makeText(RegisterMovie.this,insert,Toast.LENGTH_SHORT).show();
              }
          }
      });
    }

    }


