package com.example.cw2_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class DisplayMovie extends AppCompatActivity {
    ArrayList<Integer> movieHolder;
    ArrayList<StringBuilder> favList;
    Button favourite;
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_movie);
        listView=findViewById(R.id.listSearch);
        favourite=findViewById(R.id.btnFav);

        final Databasehelper dataBaseHelper1=new Databasehelper(this);
        Cursor cursor =new Databasehelper(this).Title();

        ArrayList<String>displayList=new ArrayList<>();

        if (cursor.getCount()==0 ){
            Toast.makeText(DisplayMovie.this,"The database was empty",Toast.LENGTH_SHORT).show();

        }
        else{
            while (cursor.moveToNext()){
                displayList.add(cursor.getString(1));
                ListAdapter listAdapter=new ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice,displayList);
                listView.setAdapter(listAdapter);
                listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                listView.setAdapter(listAdapter);



            }
        }
        favourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                favBtn(v);


            }
        });
    }



    public void generateTickBox(){
        // TODO Auto-generated method stub
ArrayList<StringBuilder> arrayList=new ArrayList<>();
        StringBuilder selected = new StringBuilder();
        int cntChoice = listView.getCount();
        SparseBooleanArray sparseBooleanArray = listView.getCheckedItemPositions();
        for(int i = 0; i < cntChoice; i++){
            if(sparseBooleanArray.get(i)) {
                selected.append(listView.getItemAtPosition(i).toString()).append("\n");
                //selected.append(arrayList);
                Toast.makeText(getApplicationContext(),selected,Toast.LENGTH_SHORT).show();
                arrayList.add(selected);

                return;
            }
        }
    }

    public void favBtn(View view) {
        generateTickBox();
        return;





    }
}