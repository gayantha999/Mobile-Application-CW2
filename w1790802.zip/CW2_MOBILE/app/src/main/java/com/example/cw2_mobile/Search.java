package com.example.cw2_mobile;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.jar.Attributes;

public class Search extends AppCompatActivity {
    EditText et1;
    Button btnSearch,btnDelete;
    Databasehelper myDB;
    ListView listView;
    String searchText;
    ArrayAdapter<String>adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        et1 = findViewById(R.id.editTextSearch);
        btnSearch = findViewById(R.id.btnSearch1);
        btnDelete = findViewById(R.id.btnSearch2);
        listView = findViewById(R.id.listSearch);
        ListView listView =(ListView)findViewById(R.id.listSearch);
        myDB=new Databasehelper(this);
        ArrayList<String>searchList=new ArrayList<>();
        searchList.addAll(Arrays.asList(getResources().getStringArray(R.array.search)));




        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                searchText=et1.getText().toString();
                if (searchText.isEmpty()){
                    et1.setError("Enter Movie title");
                    et1.requestFocus();
                    return;
                }
                else{

                    SQLiteDatabase db=getApplicationContext().openOrCreateDatabase("movie_database",Context.MODE_PRIVATE,null);
                    Cursor cursor=db.rawQuery("select * from movie_table where title ='"+searchText+"'",null);
                    if (cursor.getCount()==0){
                        Toast.makeText(getApplicationContext(),"No record found",Toast.LENGTH_SHORT).show();
                    }
                    StringBuffer buffer=new StringBuffer();
                    while (cursor.moveToNext()){
                        buffer.append("Movie Title: "+cursor.getString(1)+"\n");
                        buffer.append("Movie year: "+cursor.getString(2)+"\n");
                        buffer.append("director: "+cursor.getString(3)+"\n");
                    }

                    //Toast.makeText(getApplicationContext(),searchText,Toast.LENGTH_SHORT).show();
                    AlertDialog.Builder builder=new AlertDialog.Builder(Search.this);
                    builder.setTitle("Found Details");
                    builder.setMessage(buffer.toString());
                    builder.show();
                }
            }
        });
}}








