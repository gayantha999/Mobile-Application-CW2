package com.example.cw2_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Ratings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ratings);
    }
}